[TOC] 







<a name="jump">首页</a>     

<a name="jumpp">跳转首页</a>    



# ROS基础教程

---

---

## 4.C++/Python极简基础  

### 安装C++依赖包  

```C++
$sudo apt-get install g++
```

### 安装Python依赖包  

```C++
$sudo apt-get install python
```
---

---


## 5.ROS的安装  

### 更换Ubuntu18.04里面的软件源  

![](image/Ubuntu_pack1.png)  

这里推荐使用阿里源  

### ROS安装步骤  


- 1.添加ROS软件源  

```C++
$sudo sh -c 'echo "deb http://packages.ros.org/ros/ubuntu $(lsb_release -sc) main" > /etc/apt/sources.list.d/ros-latest.list'
```

- 2.添加秘钥  

```C++
$sudo apt-key adv --keyserver 'hkp://keyserver.ubuntu.com:80' --recv-key C1CF6E31E6BADE8868B172B4F42ED6FBAB17C654
```

- 3.安装ROS  

```C++
$sudo apt-get update	
$sudo apt-get install ros-melodic-desktop-full
```
	注意，这里在安装时一定不能报错，否则再次执行安装命令

安装完成之后的页面：  

![](image/5_melodic_install1.png "ROS环境安装成功")  

- 4.初始化rosdep  

```C++
$sudo rosdep init
$rosdep update
```

	注意：这里rosdep update更新也不能报错，否则在执行一次跟新

跟新成功之后的画面：  

![](image/5_rosdep_update1.png "rosdep跟新成功")


- 5.设置环境变量  

```C++
$echo "source /opt/ros/melodic/setup.bash" >> ~/.bashrc
$source ~/.bashrc
```
- 6.安装rosinstall

```C++
$sudo apt install python-rosinstall python-rosinstall-generator python-wstool build-essential
```

### 安装完成  

安装默认路径：`/opt/ros/melodic`  
![](image/6_melodic_dir1.png "默认安装路径")

测试安装环境：

启动ROS Master：`$roscore`
启动小海龟仿真：`$rosrun turtlesim turtlesim_node`
启动海龟控制节点：`$rosrun turtlesim turtle_teleop_key`
通过键盘方位建控制海龟运动  
![](image/5_ros_test1.png "测试成功页面")

[跳转首页](#jump)  

## 9.创建工作空间与功能包  

工作空间是一个存放工程开发相关的文件夹  
- src:代码空间  
- build:编译空间  
- devel:开发空间  
- install:安装空间  

### 创建工作空间  


#### 创建工作空间  
```c++
$mkdir -p ~/catkin_ws/src 
$cd ~/catkin_ws/src  
$catkin_init_workspace  
```

#### 编译工作空间  

```C++
$cd ~/catkin_ws  
$catkin_make  
```

#### 设置环境变量  

```C++
$source devel/setup.bash  
```

由于每次运行前都需要设置环境变量，否则会出现找不到ros相关指令，所以建议把设置环境变量这条命令写入全局变量，即写入~/.bashrc配置文件中，在最后添加命令，如下图所示（注意图片命名不能含有中文）：
![设置环境变量](image/ros_path.jpg "ROS设置环境变量")  

#### 检查环境变量  

```C++
$echo $ROS_PACKAGE_PATH  
```

如下图所示：  
![](image/ros_package_path.jpg "检查环境变量")  

### 创建一个空的功能包  
创建功能包文件夹：
![](image/ros_pack1.jpg "创建功能包")  

#### 创建功能包  

创建功能包使用的命令格式：
```C++
$catkin_create_pkg <package_name> [depend1][depend2][depend3]...  
```
创建功能包：
```C++
$cd ~/catkin_ws/src  
$catkin_create_pkg test_pkg std_msgs rospy roscpp  
```
![](image/ros_pack_test1.jpg "创建test_pkg功能包")  

这是一个空的工程包，编译功能包：
```C++
$cd ~/catkin_ws  
$catkin_make  
```
	注意：如果上面在~/.bashrc文件中设置了环境变量，这里就没问题，否则需要再次设置环境变量：source ~/catkin_ws/devel/setup.bash 后面依旧如此，不在介绍  

**同一个工作空间下，不允许存在同名功能包；不同工作空间下，允许存在同名功能包**  

**总结**  
第九章总结为三点：

- 第一，创建ROS工作空间，包括4个文件夹：```build,devel,install,src```。其中```src```是自定义新功能代码的位置，以后代码都放入此地方。  
- 第二，设置环境变量，即把```source devel/setup.bash```加入全局环境变量中。  
- 第三，了解创建和编译一个新功能包的步骤。  
[跳转首页](#jump)  
---
---

## 10.发布者publisher的编程实现  

### 话题模型  

![](image/publisher_topic_module1.jpg "publisher话题模型")  

### 创建功能包  

```C++
$cd ~/catkin_ws/src  
$catkin_create_pkg learning_topic roscpp rospy std_msgs geometry_msgs turtlesim  
```

### 创建发布者代码（C++）  

在learning_topic/src目录下创建文件：

```C++
~/catkin_ws/src/learning_topic$sudo touch velocity_publisher.cpp
~/catkin_ws/src/learning_topic$sudo chmod 777 velocity_publisher.cpp
```
添加代码：  

```C++
/**
 * 该例程将发布turtle1/cmd_vel话题，消息类型geometry_msgs::Twist
 */
 
#include <ros/ros.h>
#include <geometry_msgs/Twist.h>

int main(int argc, char **argv)
{
	// ROS节点初始化
	ros::init(argc, argv, "velocity_publisher");

	// 创建节点句柄
	ros::NodeHandle n;

	// 创建一个Publisher，发布名为/turtle1/cmd_vel的topic，消息类型为geometry_msgs::Twist，队列长度10
	ros::Publisher turtle_vel_pub = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 10);

	// 设置循环的频率
	ros::Rate loop_rate(10);

	int count = 0;
	while (ros::ok())
	{
	    // 初始化geometry_msgs::Twist类型的消息
		geometry_msgs::Twist vel_msg;
		vel_msg.linear.x = 0.5;
		vel_msg.angular.z = 0.2;

	    // 发布消息
		turtle_vel_pub.publish(vel_msg);
		ROS_INFO("Publsh turtle velocity command[%0.2f m/s, %0.2f rad/s]", 
				vel_msg.linear.x, vel_msg.angular.z);

	    // 按照循环频率延时
	    loop_rate.sleep();
	}

	return 0;
}

```
### 配置发布者代码编译规则  
修改learning_topic目录下的CMakeLists.txt文件，如何设置CMakeLists.txt中的编译规则？  
- 设置需要编译的代码和生成的可执行文件  
- 设置链接库  

```C++
add_executable(velocity_publisher src/velocity_publisher.cpp)  
target_link_libraries(velocity_publisher ${catkin_LIBRARIES})  
```
### 编译并运行发布者  

```C++
$cd ~/catkin_ws  
~/catkin_ws$catkin_make  
$roscore  
$rosrun turtlesim turtlesim_node  
$rosrun learning_topic velocity_publisher  
```
![](image/publisher_topic_module2.jpg "发布者运行结果")  



下面使用Python语言实现：

在`catkin_ws/src/learning_topic`下面创建`scripts`文件夹，用于存放`python`文件

```C++
~/catkin_ws/src/learning_topic/scripts$sudo touch velocity_publisher.py
```

内容如下：

```Pyt
#!/usr/bin/env python
# -*- coding:utf-8 -*-
# 发布turtle1/cmd_vel话题，消息类型geometry_msgs::Twist

import rospy
from geometry_msgs.msg import Twist

def velocity_publisher():
	#ROS节点初始化
	rospy.init_node('velocity_publisher', anonymous=True)
	
	# 创建一个Publisher,发布名为/turtle1/cmd_vel的topic，消息类型为 geometry_msgs::Twist,队列长度为10
	turtle_vel_pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
	
	# 设置循环的频率
	rate = rospy.Rate(10)
	
	while not rospy.is_shutdown():
		# 初始化geometry_msgs::Twist类型的消息
		vel_msg = Twist()
		vel_msg.linear.x= 0.5
		vel_msg.angular.z = 0.2
		
		#发布消息
		turtle_vel_pub.publish(vel_msg)
		rospy.loginfo("Publish turtle velocity command[%0.2f m/s, %0.2f rad/s]",
			vel_msg.linear.x,vel_msg.angular.z)
		
		# 按照循环频率延时
		rate.sleep()

if __name__=='__main__':
	try:
		velocity_publisher()
	except rospy.ROSInterruptException:
		pass

```

注意`python`编写的代码不需要添加任何其它步骤，只需给`python`文件可执行权限即可.

### 运行代码验证 

```C++
$cd ~/catkin_ws  
~/catkin_ws$catkin_make  
$roscore  
$rosrun turtlesim turtlesim_node  
$rosrun learning_topic velocity_publisher.py 
```

**总结**  

- 此例程告诉我们如何实现一个发布者，编译代码并验证  

---
---

## 11.订阅者Subscriber的编程实现  

### 话题模型  

![](image/subscriber_topic_modue1.jpg "订阅者话题模型")  

### 创建订阅者代码（C++）  

在```learning_topic```目录下创建```pose_subscriber.cpp```文件  

```C++
~/catkin_ws/src/learning_topic$sudo touch pose_subscriber.cpp
~/catkin_ws/src/learning_topic$sudo chmod 777 pose_subscriber.cpp  
```

添加代码：

```C++
/**
 * 该例程将订阅/turtle1/pose话题，消息类型turtlesim::Pose
 */
 
#include <ros/ros.h>
#include "turtlesim/Pose.h"

// 接收到订阅的消息后，会进入消息回调函数
void poseCallback(const turtlesim::Pose::ConstPtr& msg)
{
    // 将接收到的消息打印出来
    ROS_INFO("Turtle pose: x:%0.6f, y:%0.6f", msg->x, msg->y);
}

int main(int argc, char **argv)
{
    // 初始化ROS节点
    ros::init(argc, argv, "pose_subscriber");

    // 创建节点句柄
    ros::NodeHandle n;

    // 创建一个Subscriber，订阅名为/turtle1/pose的topic，注册回调函数poseCallback
    ros::Subscriber pose_sub = n.subscribe("/turtle1/pose", 10, poseCallback);

    // 循环等待回调函数
    ros::spin();

    return 0;
}

```

### 配置订阅者代码编译规则  

如何配置CMakeLists.txt中的编译规则？  

- 设置需要编译的代码和生成的可执行文件  
- 设置链接库  

```C++
add_executable(pose_subscriber src/pose_subscriber.cpp)  
target_link_libraries(pose_subscriber ${catkin_LIBRARIES})  
```

### 编译并运行订阅者  

```C++  
$cd ~/catkin_ws  
~/catkin_ws$catkin_make  
$roscore  
$rosrun turtlesim turtlesim_node  
$rosrun learning_topic pose_subscriber  
```
上面运行起来之后，显示的消息数据是当前海龟坐标，我们接下来让海龟动起来，观察订阅者的消息时候是否会变，需要启动海龟键盘控制节点，命令如下：  

```C++
$rosrun turtlesim turtle_teleop_key
```
通过移动键盘上下左右键控制海龟移动  

![](image/subscriber_topic_modue3.jpg "订阅者运行结果") 



### 创建订阅者代码（Python）

```
~/catkin_ws/src/learning_topic/scripts$sudo touch pose_subscriber.py
```

添加代码：

```Pyth
#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 例程将订阅/turtle1/pose话题，消息类型turtlesim::Pose

import rospy
from turtlesim.msg import Pose

def poseCallback(msg):
	rospy.loginfo("Turtle pose: x:%0.6f, y:%0.6f", msg.x, msg.y)

def pose_subscriber():
	# ROS节点初始化
	rospy.init_node('pose_subscrober', anonymous=True)

	# 创建一个Subscriber,订阅名为/turtle1/pose的topic,注册回调函数poseCallback
	rospy.Subscriber("/turtle1/pose", Pose, poseCallback)

	# 循环等待回调函数
	rospy.spin()

if __name__=='__main__':
	pose_subscriber()

```

### 编译并运行订阅者

```C++
$cd ~/catkin_ws  
~/catkin_ws$catkin_make  
$roscore  
$rosrun turtlesim turtlesim_node  
$rosrun learning_topic pose_subscriber.py  
$rosrun turtlesim turtle_teleop_key
```

最终效果和上面一样

**总结**  

此例程告诉我们如何实现一个订阅者，使用仿真器验证  
---  
---

## 12.话题消息的定义与使用  

### 话题模型  

![](image/pub_sub_module1.jpg "订阅发布机制")  

### 自定义话题消息  

如何自定义话题消息？  

- 定义msg文件，比如Person.msg  

在上面生成的```learning_topic```目录下创建```msg```文件夹，用于存放自定义话题消息  

```C++  
string name
uint8 sex
uint8 age  

uint8 unknown = 0
uint8 male = 1
uint8 female = 2  

```

- 在package.xml中添加功能包依赖

```C++
<build_depend>message_generation</build_depend>  
<exec_depend>message_runtime</exec_depend>  
```

- 在CMakeLists.txt添加编译选项  
在``` find_package```后面添加``` message_generation```  
去掉```catkin_package```中```CATKIN_DEPENDS```开头的注释，并在最后添加```message_runtime```  
根据文件注释提示可放在对应地方  

```C++
find_package(catkin REQUIRED COMPONENTS geometry_msgs
  roscpp
  rospy
  std_msgs
  turtlesim
  message_generation )
  
add_message_files( 
	FILES
	Person.msg 
)  
	
generate_messages( 
	DEPENDENCIES
	std_msgs 
)  

catkin_package( 
#  INCLUDE_DIRS include 
#  LIBRARIES learning_topic 
CATKIN_DEPENDS geometry_msgs roscpp rospy std_msgs turtlesim message_runtime 
#  DEPENDS system_lib )
  
```

- 编译生成语言相关文件  

在catkin_ws目录下打开终端：
```C++
$catkin_make
```

	注意这里一定要先编译生成相关文件，否则后面代码添加相关头文件会找不到内容

编译完成之后，会在`catkin_ws/devel/include/learning_topic`下生成`Person.h` 头文件  

### 创建发布者和订阅者代码(C++) 

在```learning_topic/src```目录下创建```person_publisher.cpp```和```person_subscriber.cpp```代码  

```C++
/**
 * file name：person_publisher.cpp
 *
 * 例程订阅/person_info话题，自定义消息类型learning_topic::Person
 * */

#include <ros/ros.h>
#include "learning_topic/Person.h"

int main(int argc, char **argv)
{
	//初始化ROS节点
	ros::init(argc, argv, "person_publisher");

	//创建节点句柄
	ros::NodeHandle n;

	//创建一个Publisher,发布名为/person_info的topic，消息类型为learning_topic::Person,队列长度为10
	ros::Publisher person_info_pub = n.advertise<learning_topic::Person>("/person_info",10);

	//设置循环频率
	ros::Rate loop_rate(1);

	int count = 0;

	while(ros::ok())
	{
		//初始化learning_topic::Person
		learning_topic::Person person_msg;
		person_msg.name = "Davi";
		person_msg.age = 18;
		person_msg.sex = learning_topic::Person::male;

		//发布消息
		person_info_pub.publish(person_msg);

		ROS_INFO("Publish Person Info: name:%s age:%d sex:%d",
				person_msg.name.c_str(),person_msg.age, person_msg.sex);

		//按照循环频率延时
		loop_rate.sleep();

	}

	return 0;
}

```

```C++
/**
 * file name:person_subscriber.cpp
 *
 * 例程订阅/person_info话题，自定义消息类型learning_topic::Person
 * */

#include <ros/ros.h>
#include "learning_topic/Person.h"

//接收到订阅的消息后，会进入消息回调函数
void personInfoCallback(const learning_topic::Person::ConstPtr& msg)
{
	//将接收到的消息打印出来
	ROS_INFO("Subscribe Person Info: name:%s age:%d sex:%d",
			msg->name.c_str(), msg->age, msg->sex );
}


int main(int argc, char **argv)
{
	//初始化ROS节点
	ros::init(argc, argv, "person_subscriber");

	//创建节点句柄
	ros::NodeHandle n;

	//创建一个Subscriber,订阅名为/person_info的topic，注册回调函数personInfoCallback
	ros::Subscriber person_info_sub = n.subscribe("/person_info", 10, personInfoCallback);

	//循环等待回调函数
	ros::spin();

	return 0;
}


```

### 配置代码变异规则  

如何配置CMakeLists.txt中的变异规则？  

- 设置需要编译的代码和生成的可执行文件
- 设置链接库
- 添加依赖项

```C++
add_executable(person_publisher src/person_publisher.cpp)
target_link_libraries(person_publisher ${catkin_LIBRARIES})
add_dependencies(person_publisher ${PROJECT_NAME}_generate_messages_cpp)

add_executable(person_subscriber src/person_subscriber.cpp)
target_link_libraries(person_subscriber ${catkin_LIBRARIES})
add_dependencies(person_subscriber ${PROJECT_NAME}_generate_messages_cpp)

```


### 编译并运行发布者和订阅者  

```C++
$cd ~/catkin_ws
~/catkin_ws$catkin_make
$roscore
$rosrun learning_topic person_subscriber
$rosrun learning_topic person_publisher

```

![](image/12_subscriber_publisher_module1.png)  

	注意：运行起来之后，这时关闭roscore页面，发现程序仍然可以运行，说明roscore充当master功能，对于订阅发布机制，一旦通信建立起来就不在需要master  



### 创建发布者和订阅者（python）

```

```





---

---

## 13.客户端Client的编程实现  

### 话题模型  

![](image/13_Client_topic_module1.png)  

### 创建功能包  

```C++
$cd ~/catkin_ws/src
~/catkin_ws/src$catkin_create_pkg learning_service roscpp rospy std_msgs geometry_msgs turtlesim  
```

![](image/13_create_pkg1.png)  

在```learning_service/src```目录下创建```turtle_spawn.cpp```文件  

```C++
~/catkin_ws/src/learning_service/src$sudo touch turtle_spawn.cpp  
~/catkin_ws/src/learning_service/src$sudo chmod 777 turtle_spawn.cpp
```

添加代码：  

```C++
/**
 * flie name:turtle_spawn.cpp
 *
 * 例程请求/spawn服务，服务数据类型turtlesim::Spawn
 *
 * */

#include <ros/ros.h>
#include <turtlesim/Spawn.h>


int main(int argc, char **argv)
{
	//初始化ROS节点
	ros::init(argc, argv, "turtle_spawn");

	//创建节点句柄
	ros::NodeHandle node;

	// 发现/spawn服务后，创建一个服务客户端，连接名为/spawn的service
	ros::service::waitForService("/spawn");
	ros::ServiceClient add_turtle = node.serviceClient<turtlesim::Spawn>("/spawn");

	//初始化turtlesim::Spawn的请求数据
	turtlesim::Spawn srv;
	srv.request.x = 2.0;
	srv.request.y = 2.0;
	srv.request.name = "turtle2";

	ROS_INFO("Call service to spawn turtle[x:%0.6f, y:%0.6f, name:%s]",
			srv.request.x, srv.request.y, srv.request.name.c_str());

	add_turtle.call(srv);

	//显示服务调用结果
	ROS_INFO("Spawn turtle successful [name:%s]", srv.response.name.c_str());

	return 0;
}

```

### 配置编译规则  

如何设置CMakeLists.txt中的编译规则？  

- 设置需要编译的代码和生成可执行文件  
- 设置链接库  

```C++
add_executable(turtle_spawn src/turtle_spawn.cpp)
target_link_libraries(turtle_spawn ${catkin_LIBRARIES})
```

### 编译并运行客户端  

```C++
$cd ~/catkin_ws
~/catkin_ws$catkin_make
$roscore
$rosrun turtlesim turtlesim_node
$rosrun learning_service turtle_spawn
```

![](image/13_Client_topic_module2.png "客户端运行结果")  

---

---


## 14.服务端Server的编程实现  

### 服务模型  

![](image/14_Service_module1.png  "server服务模型")  

### 创建文件  

在```~/catkin_ws/src/learning_service/src```目录下创建```turtle_command_server.cpp```文件  

```C++
~/catkin_ws/src/learning_service/src$sudo touch turtle_command_server.cpp
~/catkin_ws/src/learning_service/src$sudo chmod 777 turtle_command_server.cpp

```

添加代码：

```C++
/**
 * file name:turtle_command_server.cpp
 *
 * 例程执行/turtle_command服务，服务数据类型std_srvs/Trigger
 * */

#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include <std_srvs/Trigger.h>


ros::Publisher turtle_vel_pub;
bool pubCommand = false;

//service回调函数，输入参数req,输出参数res
bool commandCallback(std_srvs::Trigger::Request &req,
					 std_srvs::Trigger::Response &res)
{
	pubCommand = !pubCommand;

	//显示请求数据
	ROS_INFO("Publish turtle velocity command [%s]",pubCommand==true?"Yes":"No");

	//设置反馈数据
	res.success = true;
	res.message = "Change turtle command state!";

	return true;
}

int main(int argc, char **argv)
{
	//ROS节点初始化
	ros::init(argc, argv, "turtle_command_server");

	//创建节点句柄
	ros::NodeHandle n;

	//创建一个名为/turtle_command的server,注册回调函数commandCallback
	ros::ServiceServer command_service = n.advertiseService("/turtle_command",commandCallback);

	//创建一个Publisher,发布名为/turtle1/cmd_vel的topic,消息类型为geometry_msgs::Twist,队列长度10
	turtle_vel_pub = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel",10);

	//循环等待回调函数
	ROS_INFO("Ready to receive turtle command");

	//设置循环的频率
	ros::Rate loop_rate(10);

	while(ros::ok())
	{
		//查看一次回调函数队列
		ros::spinOnce();

		//如果标志为true,则发布速度指令
		if(pubCommand)
		{
			geometry_msgs::Twist vel_msg;
			vel_msg.linear.x = 0.5;
			vel_msg.angular.z = 0.2;
			turtle_vel_pub.publish(vel_msg);
		}

		//按照循环频率延时
		loop_rate.sleep();
	}

	return 0;
}
```

### 配置编译规则  

如何配置CMakeLists.txt的编译规则？

- 设置需要编译的代码和生成的可执行文件  
- 设置链接库  

```C++
add_executable(turtle_command_server src/turtle_command_server.cpp)  
target_link_libraries(turtle_command_server ${catkin_LIBRARIES})

```

### 编译并运行服务器  

```C++
cd ~/catkin_ws
~/catkin_ws$catkin_make
$roscore
$rosrun turtlesim turtlesim_node
$rosrun learning_service turtle_command_server
$rosservice call /turtle_command "{}"
```

![](image/14_Service_module2.png "服务器例程运行效果")  

---

---

## 15.服务数据的定义与使用  


### 服务模型  

![](image/15_server_date_use_mode1.png "服务模型")  

### 自定义服务数据  

如何自定义服务数据？  

- 定义srv文件，如Person.srv  

在```learning_service```中创建一个```srv```文件夹，并在此文件夹创建```Person.srv```文件  
添加文件内容如下：

```C++
string name
uint8 age
uint8 sex

uint8 unknown = 0
uint8 male = 1
uint8 female = 2

---
string result

```

- 在```package.xml```中添加功能包依赖  

```C++
<build_depend>message_generation</build_depend>
<exec_depend>message_runtime</exec_depend>
```

- 在```CMakeLists.txt```添加编译选项  
	- 在```find_package```后面添加```message_generation```
	在```catkin_package```上去掉```CATKIN_DEPENDS```前的注释，并在末尾添加```message_runtime```

```C++
find_package(catkin REQUIRED COMPONENTS
  geometry_msgs
  roscpp
  rospy
  std_msgs
  turtlesim
  message_generation
)


add_service_files(
	FILES
	Person.srv
)

generate_messages(
	DEPENDENCIES
	std_msgs
)

catkin_package(
#  INCLUDE_DIRS include
#  LIBRARIES learning_service
   CATKIN_DEPENDS geometry_msgs roscpp rospy std_msgs turtlesim message_runtime
#  DEPENDS system_lib

)
```

### 编译生成语言相关文件  

```C++
$cd ~/catkin_ws
~/catkin_ws$catkin_make
```

在```~/catkin_ws/devel/include/learning_service```下会生成```Person.h``` ```PersonRequest.h``` ```PersonResponse.h```三个头文件  

### 创建服务器和客户端代码  

在```learning_service/src```下创建```person_client.cpp```和```person_server.cpp```文件  

```C++
/**
 * file name:person_client.cpp
 *
 * 例程将请求/show_person服务，服务数据类型learning_service::Person
 * */

#include <ros/ros.h>
#include "learning_service/Person.h"


int main(int argc, char **argv)
{
	//初始化ROS节点
	ros::init(argc, argv, "person_client");

	//创建节点句柄
	ros::NodeHandle node;

	//发现/show_person服务后，创建一个服务客户端，连接名为/show_person的service
	ros::service::waitForService("/show_person");
	ros::ServiceClient person_client = node.serviceClient<learning_service::Person>("/show_person");

	//初始化learning_service::Person的请求数据
	learning_service::Person srv;
	srv.request.name = "Jack";
	srv.request.age = 20;
	srv.request.sex = learning_service::Person::Request::male;

	//请求服务调用
	ROS_INFO("Call service to show person[name:%s, age:%d, sex:%d]",
			srv.request.name.c_str(), srv.request.age, srv.request.sex);

	person_client.call(srv);

	//显示服务调用结果
	ROS_INFO("Show person result : %s",srv.response.result.c_str());

	return 0;
}
```

```C++
/**
 * file name:person_server.cpp
 *
 * 例程执行/show_person服务，服务数据类型learning_service::Person
 * */

#include <ros/ros.h>
#include "learning_service/Person.h"

//service回调函数，输入参数req,输出参数res
bool personCallback(learning_service::Person::Request &req,
					learning_service::Person::Response &res)
{
	//显示请求数据
	ROS_INFO("Person: name:%s age:%d sex:%d",req.name.c_str(), req.age, req.sex);

	//设置反馈数据
	res.result = "OK";

	return true;
}

int main(int argc, char **argv)
{
	//ROS节点初始化
	ros::init(argc, argv, "person_server");

	//创建节点句柄
	ros::NodeHandle n;

	//创建一个名为/show_person的server,注册回调函数personCallback
	ros::ServiceServer person_service = n.advertiseService("/show_person", personCallback);

	//循环等待回调函数
	ROS_INFO("Ready to show person information");

	ros::spin();

	return 0;
}


```

### 配置服务器/客户端代码编译规则  

如何配置CMakeLists.txt中的编译规则？  

- 设置需要编译的代码和生成的可执行文件  
- 设置链接库  
- 设置依赖项  

```C++
add_executable(person_server src/person_server.cpp)
target_link_libraries(person_server ${catkin_LIBRARIES})
add_dependencies(person_server ${PROJECT_NAME}_gencpp)

add_executable(person_client src/person_client.cpp)
target_link_libraries(person_client ${catkin_LIBRARIES})
add_dependencies(person_client ${PROJECT_NAME}_gencpp)

```

### 编译并运行客户端和服务器  

```C++
$cd ~/catkin_ws
~/catkin_ws$catkin_make
$roscore 
$rosrun learning_service person_server
$rosrun learning_service person_client
```

![](image/15_server_date_use_mode2.png "客户端和服务器运行结果")

---

---

## 16.参数的使用与编程方法  

### 参数模型  

![](image/16_params_module1.png "参数模型")

### 创建功能包  

```C++
$cd ~/catkin_ws/src
~/catkin_ws/src$catkin_create_pkg learning_parameter roscpp rospy std_srvs  
```

![](image/16_params_create1.png "参数功能包创建")  


### 参数命令行的使用  

首先让海龟跑起来，然后在查看参数  

```C++
$roscore
$rosrun turtlesim turtlesim_node
```

常用参数命令：  

- 列出当前所有参数：`$rosparam list`
- 显示某个参数值：`$rosparam get param_key`
- 设置某个参数值：`$rosparam set param_key param_value`
- 保存参数到文件：`$rosparam dump file_name`
- 从文件读取参数：`$rosparam load file_name`
- 删除参数：`$rosparam delete param_key`

让海龟出现之后，查看当前所有参数：  
```C++
$rosparam list
```
![](image/16_params_list1.png "查看所有参数")

获取海龟背景颜色值：`rosparam get /background_b`  

![](image/16_params_get1.png "获取背景颜色的值")  

设置背景颜色：`rosparam set /background_b 0`
查看背景颜色值：`rosparam get /background_b 
然后在跟新海龟背景颜色：`rosservice call /clear "{}" `,发现海龟默认蓝色背景变化了。  

![](image/16_params_set_get1.png "参数设置效果")

如果参数过多或需要保存参数，可以使用yaml文件统一加载。  
导出参数：`rosparam dump param.yaml`文件。保存路径为当前命令行路径  
可以直接在yaml文件修改参数，然后在加载文件即可。`rosparam load param.yaml`  

### 创建代码  

```C++
$cd ~/katkin_ws/src/learning_parameter/src
~/katkin_ws/src/learning_parameter/src$sudo touch parameter_config.cpp
```
添加代码内容：
```C++
/**
 * file name:parameter_config.cpp
 *
 * 例程设置/读取海龟中的参数
 *
 * */

#include <string>
#include <ros/ros.h>
#include <std_srvs/Empty.h>


int main(int argc, char **argv)
{
	int red,green,blue;

	//ROS节点初始化
	ros::init(argc, argv, "parameter_config");

	//创建节点句柄
	ros::NodeHandle node;

	//读取背景颜色参数
	ros::param::get("/background_r", red);
	ros::param::get("/background_g", green);
	ros::param::get("/background_b", blue);
	ROS_INFO("Get Background Colur[%d %d %d]",red, green, blue);

	//设置背景颜色参数
	ros::param::set("/background_r", 255);
	ros::param::set("/background_g", 255);
	ros::param::set("/background_b", 255);
	ROS_INFO("Set Background Color[255 255 255]");

	//读取背景颜色参数
	ros::param::get("/background_r", red);
	ros::param::get("/background_g", green);
	ros::param::get("/background_b", blue);
	ROS_INFO("Re-get Background Color[%d, %d, %d]",red, green, blue);

	//调用服务，刷新背景颜色
	ros::service::waitForService("clear");
	ros::ServiceClient clear_background = node.serviceClient<std_srvs::Empty>("/clear");
	std_srvs::Empty srv;
	clear_background.call(srv);

	sleep(1);
	return 0;
}

```
### 配置代码编译规则  

如何配置CMakeLists.txt中的编译规则？  


- 设置需要编译的代码和生成的可执行文件  
- 设置链接库  

```C++
add_executable(parameter_config src/parameter_config.cpp)
target_link_libraries(parameter_config ${catkin_LIBRARIES})

```

### 编译并运行代码  

```C++
$cd ~/catkin_ws
~/catkin_ws$catkin_make
$roscore
$rosrun turtlesim turtlesim_node
$rosrun learning_parameter parameter_config
```
![](image/16_params_turtlesim_defult1.png "默认海龟颜色背景")  

运行之后的结果：  

![](image/16_params_turtlesim_config1.png "设置参数修改之后的背景")

---

---

## 17.ROS中的坐标系管理系统  

### 机器人中的坐标变换  

![](image/17_rebot1.png "机器人中的坐标变换")  

TF功能包能干什么？  

- 5秒钟之前，机器人头部坐标系相对于全局坐标系的关系是什么样的？  
- 机器人夹取的物体相对于机器人中心坐标系的位置在哪里？
- 机器人中心坐标系相对于全局坐标系的位置在哪里？

TF坐标变换如何实现？  

- 广播TF变换
- 监听TF变换  

运行例程：  

```C++
$sudo apt-get	install ros-melodic-turtle-tf
$roslaunch turtle_tf turtle_tf_demo.launch
$rosrun turtlesim turtle_teleop_key
$rosrun tf view_frames
```
![](image/17_rebot2.png "运行系统例程")  

其中运行`rosrun tf view_frames`会在终端当前路径下创建一个`frames.pdf`文档，内容如下：

![](image/17_rebot_view_frame1.png "view框架图")

使用键盘控制节点可以控制海龟移动，另一个海龟会跟随。

使用命令：`rosrun tf tf_echo turtle1 turtle2
`可以看到海龟实时坐标。  

![](image/17_reboot_move1.png "显示海龟坐标")  

也可以用可视化工具：  

```C++
$rosrun rviz rviz -d 'rospack find turtle_tf' /rviz/turtle_rviz.rviz
```
![](image/17_reboot_move2.png "可视化工具显示海龟坐标")  



## 18.tf坐标系广播与监听的编程实现  

### 创建功能包  

```C++
cd ~/catkin_ws/src
~/catkin_ws/src$catkin_create_pkg learning_tf roscpp rospy tf turtlesim  
```

### 创建tf广播器和监听器代码  

```C++
~/catkin_ws/src/learning_tf/src$sudo touch turtle_tf_broadcaster.cpp turtle_tf_listener.cpp
```

添加代码：

```C++
/**
 * file nale:turtle_tf_broadcaster.cpp
 *
 * 例程产生TF数据，并计算，发布turtle2的速度指令
 *
 * */

#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include <turtlesim/Pose.h>

std::string turtle_name;

void poseCallback(const turtlesim::PoseConstPtr& msg)
{
	//创建tf广播器
	static tf::TransformBroadcaster br;

	//初始化tf数据
	tf::Transform transform;
	transform.setOrigin(tf::Vector3(msg->x, msg->y, 0.0));
	tf::Quaternion q;
	q.setRPY(0, 0, msg->theta);
	transform.setRotation(q);

	//广播world与海龟坐标系的tf数据
	br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "world", turtle_name));

}

int main(int argc, char **argv)
{
	//初始化ROS节点
	ros::init(argc, argv, "my_tf_broadcaster");

	// 输入参数作为海龟的名字
	if(argc != 2)
	{
		ROS_ERROR("need turtle name as arguement");
		return -1;
	}

	turtle_name = argv[1];

	// 订阅海龟的位置话题
	ros::NodeHandle node;
	ros::Subscriber sub = node.subscribe(turtle_name+"/pose", 10, &poseCallback);

	//循环等待回调函数
	ros::spin();

	return 0;
}


```

```C++
/**
 * file name:turtle_tf_listener.cpp
 *
 * 例程监听tf数据，并计算，发布turtle2的速度指令
 *
 * */

#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <geometry_msgs/Twist.h>
#include <turtlesim/Spawn.h>


int main(int argc, char **argv)
{
	//初始化ros
	ros::init(argc, argv, "my_tf_listener");

	//创建节点句柄
	ros::NodeHandle node;

	//请求产生turtle2
	ros::service::waitForService("/spawn");
	ros::ServiceClient add_turtle = node.serviceClient<turtlesim::Spawn>("/spawn");
	turtlesim::Spawn srv;
	add_turtle.call(srv);

	// 创建发布turtle2速度控制指令的发布者
	ros::Publisher turtle_vel = node.advertise<geometry_msgs::Twist>("/turtle2/cmd_vel", 10);


	//创建tf的监听器
	tf::TransformListener listener;

	ros::Rate rate(10.0);

	while(node.ok())
	{
		//获取turtle1与turtle2坐标之间的tf数据
		tf::StampedTransform transform;
		try
		{
			listener.waitForTransform("/turtle2", "/turtle1", ros::Time(0), ros::Duration(3.0) );
			listener.lookupTransform("/turtle2", "/turtle1", ros::Time(0), transform);
		}
		catch(tf::TransformException &ex)
		{
			ROS_ERROR("%s", ex.what());
			ros::Duration(1.0).sleep();
			continue;
		}

		//根据turtle1与turtle2坐标之间的位置关系，发布turtle2的速度控制指令
		geometry_msgs::Twist vel_msg;
		vel_msg.angular.z = 4.0 * atan2(transform.getOrigin().y(),
										transform.getOrigin().x());
		vel_msg.linear.x = 0.5 * sqrt(pow(transform.getOrigin().x(),2) +
									  pow(transform.getOrigin().y(),2));

		turtle_vel.publish(vel_msg);

		rate.sleep();

	}

	return 0;
}

```

### 配置tf广播器与监听器代码编译规则  

如何配置CMakeLists.txt中的编译规则？  

- 设置需要编译的代码和生成的可执行文件
- 设置链接库

```C++
add_executable(turtle_tf_broadcaster src/turtle_tf_broadcaster.cpp)
target_link_libraries(turtle_tf_broadcaster ${catkin_LIBRARIES})

add_executable(turtle_tf_listener src/turtle_tf_listener.cpp)
target_link_libraries(turtle_tf_listener ${catkin_LIBRARIES})

```

### 编译并运行  

```C++
cd ~/catkin_ws
~/catkin_ws$catkin_make
$roscore
$rosrun turtlesim turtlesim_node
$rosrun learning_tf turtle_tf_broadcaster __name:=turtle1_tf_broadcaster /turtle1
$rosrun learning_tf turtle_tf_broadcaster __name:=turtle2_tf_broadcaster /turtle2
$rosrun learning_tf turtle_tf_listener
$rosrun turtlesim turtle_teleop_key
```
运行结果：

![](image/18_tf_listener1.png "tf跟随实验结果")

---

---

## 19.launch启动文件的使用方法  

### Launch文件语法  

`launch`文件中的根元素采用`<launch>`标签定义  

启动节点  
`<node pkg="package-name" type="executable-name" name="node-name" />`  

- pkg：节点所在的功能包名称  
- type：节点的可执行文件名  
- name：节点运行时的名称  
- output,respawn,required,ns,args等等

### Launch文件  

通过XML文件实现多节点的配置和启动（可自启动ROS Master）  

创建一个`learning_launch`功能包：

```C++
~/catkin_ws/src$catkin_create_pkg learning_launch
```
launch文件是启动其它文件的，所以不需要依赖。  
一般会创建`launch`文件夹，存放launch文件。然后创建后缀名为`launch`的文件，如：`simple.launch`文件,内容如下：  

```C++
<launch>
    <node pkg="learning_topic" type="person_subscriber" name="talker" output="screen" />
    <node pkg="learning_topic" type="person_publisher" name="listener" output="screen" /> 
</launch>
```
然后启动`launch`文件。
```C++
$roslaunch learning_launch simple.launch
```
`simple.launch`文件内容如下：  
```XML
<launch>
    <node pkg="learning_topic" type="person_subscriber" name="talker" output="screen" />
    <node pkg="learning_topic" type="person_publisher" name="listener" output="screen" /> 
</launch>

```
这个例程实现的是自定义订阅发布消息  

下面实现发布者订阅，使用`launch`文件启动  
先回顾之前的启动方式：
```C++
$cd ~/catkin_ws  
~/catkin_ws$catkin_make  
$roscore  
$rosrun turtlesim turtlesim_node  
$rosrun learning_topic velocity_publisher  
```
下面该为`launch`文件启动：
```XML
<launch>
	<node pkg="turtlesim" type="turtlesim_node" name="turtlesim_node" output="screen" />
	<node pkg="learning_topic" type="velocity_publisher" name="test1" output="screen" />
</launch>
```
![](image/19_launch_publisher1.png "launch文件启动发布者")  

---

下面使用`launch`文件实现订阅者机制  
先来回顾下订阅者的启动方式：  
```C++
$cd ~/catkin_ws  
~/catkin_ws$catkin_make  
$roscore  
$rosrun turtlesim turtlesim_node  
$rosrun learning_topic pose_subscriber  
$rosrun turtlesim turtle_teleop_key  
```
下面改用`launch`文件  
```xml
<launch>
	<node pkg="turtlesim" type="turtlesim_node" name="turtlesim_node" output="screen" />
	<node pkg="learning_topic" type="pose_subscriber" name="pose_subscriber" output="screen" />
	<node pkg="turtlesim" type="turtle_teleop_key" name="turtle_teleop_key" output="screen" /> 
</launch>

```
### 创建launch功能包  

```C++
$cd ~/catkin_ws/src
~/catkin_ws/src$catkin_create_pkg learning_launch
```
	注意：由于launch文件只是启动其它文件，所以不需要任何依赖  

然后在`learning_launch`文件夹创建`launch`文件夹，用于存放创建的文件，可以将上述的launch文件放入此地方，然后运行命令，如：`$roslaunch learning_launch simple.launch`  



## 机器人建模与仿真  

### 6.1.1 <link>标签  

<link>标签用来描述机器人某个刚体部分的外观和物理属性，包括尺寸（size）、颜色（color）、形状（shape）、惯性矩阵（inertialmatrix）、碰撞参数(collision properties)等。

```xml
<link name="link name">
    <inertial>......</inertial>
    	<visual>......</visual>
    	<collision>......</collision>
</link>

```

- inertial:描述惯性参数  
- visual:描述机器人link部分的外观参数
- collision:描述link的碰撞属性

### 6.1.2 <joint>标签

- <joint>标签用于描述机器人关节的运动学和动力学属性，包括关节运动的位置和速度限制。  

  下图表示URDF模型中的joint类型

|  关节类型  |                      描述                       |
| :--------: | :---------------------------------------------: |
| continuous |         旋转关节，可以围绕单轴无限旋转          |
|  revolute  | 旋转关节，类似于continuous,但是有旋转的角度极限 |
| prismatic  |  滑动关节，沿某一轴线移动的关节，带有位置极限   |
|   planar   |   平面关节，允许在平面正交方向上平移或者旋转    |
|  floating  |        浮动关节，允许进行平移、旋转运动         |
|   fixed    |         固定关节，不允许运动的特殊关节          |

与人的关节一样，机器人关节的主要作用是连接两个刚体`link`,这两个`link`分别称为`parent link`和`child link` ,<joint>标签的描述语法如下：

```xml
<joint name="<name of the joint>">
    <parent link="parent_link"/>
    <child link="child_link"/>
    <calibration.../>
    <dynamics damping.../>
    <limit effort.../>
    ...
</joint>
```

其中必须指定`joint`的`parent link`和`child link`,还可以设置关节的其它属性。

<calibration>:关节的参考位置，用来校准关节的绝对位置。

<dynamics>:用于描述关节的物理属性，例如阻尼值、物理静摩擦力等

<limit>:用于描述运动的一些极限值，包括关节运动的上下限位置、速度限制、力矩限制等。

<mimic>:用于描述该关节与已有关节的关系。

<safety_controller>:用于描述安全控制器参数。:baby_symbol:

:star:

## 6.1.3 robot标签

<robot>是完整机器人模型的最顶层标签，<link>和<joint>标签都必须包含在<robot>标签内。一个完整的机器人模型有一系列<link>和<joint>组成。

<robot>标签可以内置机器人的名字，其基本语法如下：

```xml
<robot name="<name of the robot>">
    <link>......</link>
    <joint>......</joint>
    ...
</robot>
```

## 6.1.4 gazebo标签

<gazebo>标签用于描述机器人模型在`Gazebo`中仿真所需要的参数，包括机器人材料的属性、`gazebo`插件等。该标签不是机器人模型必须的部分，只有在`gazebo`仿真时需加入。

```xml
<gazebo reference="link_1">
    <material>Gazebo/Black</material>
</gazebo>
```





URDF提供了一些命令行工具，可以帮助我们检查、梳理模型文件，需要在终端中独立安装：  

`$sudo apt-get install liburdfdom-tools`  

然后使用`check_urdf`命令对`mrobot_chassis.urdf`进行检查：

`$check_urdf mrobot_chassis.urdf`

还可以使用`urdf_to_graphiz`命令查看`URDF`模型的整体结构：

`urdf_to_graphiz mrobot_chassis.urdf`

打开`pdf`文档命令：`evince`



描述尺寸外观，如果是长方形：`<box size="10 11 12"/>`即描述长宽高尺寸(单位默认米)，如果是圆柱：`<cylinder radius="0.033" length="0.017"/>` 即半径是3.3cm,高1.7cm。

### 1.ROS坐标系统 

## 2.jump



当工作于参考工作空间，记住：ROS使用右手定义：

![](image/ros_position1.png)

所以，对于ROS机器人，如果以它为坐标系的原心，那么：

- x轴：前方
- y轴：左方
- z轴：上方

![](image/ros_position2.png) 

### 2.在一个轴线上的旋转，也使用右手定义

![](image/ros_position3.png) 

###  3.测量单位



ROS使用公制：

- 线速度：m/s
- 角速度：rad/s

线速度`=0.5m/s`对于一个室内机器人来说是一个相当快的速度了。角速度`=1.0rad/s`就是旋转一圈6秒钟。

[跳转首页](#jump)   

[跳转到标题](#2.jump)  

[首页跳转](#jumpp)  

## 6.2 创建机器人URDF模型  

### 6.2.1 创建机器人描述功能包 

```C++
~/catkin_ws/src$catkin_create_pkg mrobot_description urdf xacro
```

`mrobot_description`功能包中包含`urdf`、`meshes`、`launch`、和`config` 四个文件夹。

- urdf：于存放机器人模型的URDF或xacro文件。
- meshes：用于存放URDF中引用的模型渲染文件。
- launch：用于保存相关启动文件。
- config：用于保存`rviz` 的配置文件。

###  6.2.2 创建URDF模型  

```C++
~/catkin_ws/src/mrobot_description/urdf$touch mrobot_chassis.urdf
```



在前面大致了解了`URDF` 模型中常用的标签和语法，下面创建一个机器人底盘模型。

这个机器人底盘有6个`link` 和5个`joint` 。7个`link` 包括1个机器人底板、2个电机、2个驱动轮和1个万向轮；5个`joint` 负责将驱动轮、万向轮、电机安装到底板上，并设置相应的连接方式。

```xml
<?xml version="1.0" ?>
<robot name="mrobot_chassis">
	<link name="base_link">
		<visual>
			<origin xyz="0 0 0" rpy="0 0 0"/>
			<geometry>
				<cylinder length="0.005" radius="0.13"/>
			</geometry>
			<material name="yellow">
				<color rgba="1 0.4 0 1"/>
			</material>
		</visual>
	</link>
	
	<joint name="base_left_motor_joint" type="fixed">
		<origin xyz="-0.055 0.075 0" rpy="0 0 0"/>
		<parent link="base_link"/>
		<child link="left_motor"/>
	</joint>
	
	<link name="left_motor">
		<visual>
			<origin xyz="0 0 0" rpy="1.5707 0 0"/>
			<geometry>
				<cylinder radius="0.02" length="0.08"/>
			</geometry>
			<material name="gray">
				<color rgba="0.75 0.75 0.75 1"/>
			</material>
		</visual>
	</link>
	
	<joint name="left_wheel_joint" type="continuous">
		<origin xyz="0 0.0485 0" rpy="0 0 0"/>
		<parent link="left_motor"/>
		<child link="left_wheel_link"/>
		<axis xyz="0 1 0"/>
	</joint>
	
	<link name="left_wheel_link">
		<visual>
			<origin xyz="0 0 0" rpy="1.5707 0 0"/>
			<geometry>
				<cylinder radius="0.033" length="0.017"/>
			</geometry>
			<material name="white">
				<color rgba="1 1 1 0.9"/>
			</material>
		</visual>
	</link>
	
	<joint name="base_right_motor_joint" type="fixed">
		<origin xyz="-0.055 -0.075 0" rpy="0 0 0"/>
		<parent link="base_link"/>
		<child link="right_motor"/>
	</joint>
	
	<link name="right_motor">
		<visual>
			<origin xyz="0 0 0" rpy="1.5707 0 0"/>
			<geometry>
				<cylinder radius="0.02" length="0.08"/>
			</geometry>
			<material name="gray">
				<color rgba="0.75 0.75 0.75 1"/>
			</material>
		</visual>
	</link>
	
	<joint name="right_wheel_joint" type="continuous">
		<origin xyz="0 -0.0485 0" rpy="0 0 0"/>
		<parent link="right_motor"/>
		<child link="right_wheel_link"/>
		<axis xyz="0 1 0"/>
	</joint>
	
	<link name="right_wheel_link">
		<visual>
			<origin xyz="0 0 0" rpy="1.5707 0 0"/>
			<geometry>
				<cylinder radius="0.033" length="0.017"/>
			</geometry>
			<material name="white">
				<color rgba="1 1 1 0.9"/>
			</material>
		</visual>
	</link>
	
	<joint name="front_caster_joint" type="fixed">
		<origin xyz="0.1135 0 -0.0165" rpy="0 0 0"/>
		<parent link="base_link"/>
		<child link="front_caster_link"/>
	</joint>
	
	<link name="front_caster_link">
		<visual>
			<origin xyz="0 0 0" rpy="1.5707 0 0"/>
			<geometry>
				<sphere radius="0.0165"/>
			</geometry>
			<material name="black">
				<color rgba="0 0 0 0.95"/>
			</material>
		</visual>
	</link>

</robot>


```

`URDF`提供了一些命令行工具，可以帮助我们检查、梳理模型文件，需要在终端中独立安装：

```C++
$sudo apt-get install liburdfdom-tools
```

然后使用`check_urdf`命令对`mrobot_chassis.urdf`文件进行检查：

```C++
$check_urdf mrobot_chassis.urdf
```

`check_urdf`命令会解析URDF文件，并且显示解析过程中发现的错误。如果一切正常，在终端中会输出如下信息：

![](image/urdf_check1.png "URDF CHeck正确")



### 6.2.3 URDF文件解析



### 6.2.4 在rviz中显示

在launch文件夹下面创建一个launch文件。

```C++
~/catkin_ws/src/mrobot_description/launch$touch display_mrobot_chassis_urdf.launch
```

代码如下：

```xml
<launch>
	<param name="robot_description" textfile="$(find mrobot_description)/urdf/mrobot_chassis.urdf"/>
	
	<!-- 设置GUI参数，显示关节控制插件 -->
	<param name="use_gui" value="true"/>
	
	<!-- 运行joint_state_publisher_gui节点，发布机器人的关节状态  -->
	<node name="joint_state_publisher_gui" pkg="joint_state_publisher_gui" type="joint_state_publisher_gui"/>
	
	<!-- 运行robot_state_publisher节点，发布tf  -->
	<node name="robot_state_publisher" pkg="robot_state_publisher" type="robot_state_publisher"/>
	
	<!-- 运行rviz可视化界面 -->
	<node name="rviz" pkg="rviz" type="rviz" args="-d $(find mrobot_description)/config/mrobot_urdf.rviz" required="true" />

</launch>
```

打开终端运行该launch文件，如果一切正常，可以在打开的rviz中看到机器人模型。

```C++
$roslaunch mrobot_description display_mrobot_chassis_urdf.launch
```

![](image/rviz_module1.png "机器人模型")

## 6.3 改进URDF模型

上面的模型还非常简陋，仅可在rviz中可视化显示，如果将其放入到仿真环境中，还需要进一步改进。

### 6.3.1 添加物理和碰撞属性

在之前的模型中，我们仅创建了模型外观的可视化属性，除此之外，还需要添加物理属性和碰撞属性。这里以机器人底盘为例子，添加这些属性。

在`base_link`中加入<inertial>和<collision>标签，描述机器人的物理属性和碰撞属性：

```xml
<link name="base_link">
	<interial>
        <mass value="2"/>
        <origin xyz="0 0 0.0"/>
        <inertia ixx="0.01" ixy="0.0" ixz="0.0"
                 iyy="0.01" iyz="0.0" izz="0.5"/>
    </interial>
    <visual>
        <origin xyz="0 0 0" rpy="0 0 0"/>
        <geometry>
         	<cylinder length="${base_link_length}" radius="${base_link_radius}"/>
        </geometry>
        <material name="yellow"/>
    </visual>
    <collision>
        <origin xyz="0 0 0" rpy="0 0 0"/>
        <geometry>
            <cylinder length="${base_link_length}" radius="${base_link_radius}"/>
        </geometry>
    </collision>
</link>
```

### 6.3.2 使用xacro优化URDF

- 精简模块代码：xacro是一个精简版本的urdf文件，在xacro文件中，可以通过创建宏定义的方式定义常量或者服用代码，不仅可以减少代码量，而且可以让模型代码更加模块化、更具可读性。

- 提供可编程接口：xacro的语法支持一些可编程接口，如常量、变量、数学公式、条件语句等，可以让建模工程更加只能有效。

  xacro是URDF的升级版本，模型文件的后缀名由.urdf变成.xacro，而且在模型<robot>标签中需要加入xacro的声明：

  ```xml
  <?xml version="1.0"?>
  <robot name="robot_name" xmlns:xacro="http://www.ros.org/wiki/xacro">
  ```

  

### 6.3.3 xacro文件引用

改进后的模型文件是`mrobot.urdf.xacro`,详细内容如下：

```xml
<?xml version="1.0"?>
<robot name="mrobot" xmlns:xacro="http://www.ros.org/wiki/xacro">
    <xacro:include filename="$(find mrobot_description)/urdf/mrobot_body.urdf.xacro"/>
    
    <!-- MRobot机器人平台 -->
    <mrobot_body>
</robot>
```

<robot>标签之间只有两行代码。

第一行代码描述该xacro文件所包含的其他xacro文件，类似于C语言的include文件。

第二行代码就调用了被包含文件`mrobot_body.urdf.xacro`中的机器人模型。

### 6.3.4 显示优化后的模型

xacro文件设计完成后，可以通过两种方式将优化后的模型显示在rviz中：

- 1.将xacro文件转化为URDF文件

  使用如下命令转化：

  ```xml
  $rosrun xacro xacro.py mrobot.urdf.xacro > mrobot.urdf
  ```

  当前目录下会生成一个转化后的URDF文件，然后使用上面的launch文件可将URDF模型显示在rviz中。

- 2.直接调用xacro文件解析器

  也可以省略手动转化模型的过程，直接在启动文件中调用xacro解析器，自动将xacro转化成URDF文件。配置launch文件：

  ```xml
  <arg name="model" default="$(find xacro)/xacro --inorder '$(find mrobot_description)/urdf/mrobot.urdf.xacro'" />
  ```

  

  修改后的代码如下：

  先是`mrobot.urdf.xacro`文件：

  ```xml
  <?xml version="1.0"?>
  <robot name="mrobot" xmlns:xacro="http://www.ros.org/wiki/xacro">
  	<xacro:include filename="$(find mrobot_description)/urdf/mrobot_body.urdf.xacro"/>
  	<!--MRobot机器人平台-->
  	<mrobot_body/>
  </robot>
  
  ```

  `mrobot_body.urdf.xacro`文件：

  ```xml
  <?xml version="1.0"?>
  <robot xmlns:xacro="http://www.ros.org/wiki/xacro">
  
  	<xacro:property name="M_PI" value="3.14159"/>
  	<xacro:property name="wheel_radius" value="0.033"/>
  	<xacro:property name="wheel_length" value="0.017"/>
  	<xacro:property name="base_link_radius" value="0.13"/>
  	<xacro:property name="base_link_length" value="0.005"/>
  	<xacro:property name="motor_radius" value="0.02"/>
  	<xacro:property name="motor_length" value="0.08"/>
  	<xacro:property name="motor_x" value="-0.055"/>
  	<xacro:property name="motor_y" value="0.075"/>
  	<xacro:property name="plate_height" value="0.07"/>
  	<xacro:property name="standoff_x" value="0.12"/>
  	<xacro:property name="standoff_y" value="0.10"/>
  	
  	<mrobot_standoff_2in parent="base_link" number="1" x_loc="-${standoff_x/2 + 0.03}" y_loc="-${standoff_y - 0.03}" z_loc="${plate_height/2}" />
  	<mrobot_standoff_2in parent="base_link" number="2" x_loc="-${standoff_x/2 + 0.03}" y_loc="${standoff_y - 0.03}" z_loc="${plate_height/2}"/>
  	<mrobot_standoff_2in parent="base_link" number="3" x_loc="${standoff_x/2}" y_loc="-${standoff_y}" z_loc="${plate_height/2}"/>
  	<mrobot_standoff_2in parent="base_link" number="4" x_loc="${standoff_x/2}" y_loc="${standoff_y}" z_loc="${plate_height/2}"/>
  	
      <mrobot_standoff_2in parent="standoff_2in_1_link" number="5" x_loc="0" y_loc="0" z_loc="${plate_height}"/>
      <mrobot_standoff_2in parent="standoff_2in_2_link" number="6" x_loc="0" y_loc="0" z_loc="${plate_height}"/>
      <mrobot_standoff_2in parent="standoff_2in_3_link" number="7" x_loc="0" y_loc="0" z_loc="${plate_height}"/>
      <mrobot_standoff_2in parent="standoff_2in_4_link" number="8" x_loc="0" y_loc="0" z_loc="${plate_height}"/>
  	
  	<!-- 定义MRobot本体的宏 -->
  	<xacro:macro name="mrobot_standoff_2in" params="parent number x_loc y_loc z_loc">
  		<joint name="standoff_2in_${number}_joint" type="fixed">
  			<origin xyz="${x_loc} ${y_loc} ${z_loc}" rpy="0 0 0"/>
  			<parent link="${parent}"/>
  			<child link="standoff_2in_${number}_link"/>
  		</joint>
  		
  		<link name="standoff_2in_${number}_link">
  			<inertial>
  				<mass value="0.001"/>
  				<origin xyz="0 0 0"/>
  				<inertia ixx="0.0001" ixy="0.0" ixz="0.0"
  						 iyy="0.0001" iyz="0.0"
  						 izz="0.0001"/>
  			</inertial>
  			<visual>
  				<origin xyz="0 0 0" rpy="0 0 0"/>
  				<geometry>
  					<box size="0.01 0.01 0.07"/>
  				</geometry>
  				<material name="black">
  					<color rgba="0.16 0.17 0.15 0.9"/>
  				</material>
  			</visual>
  			<collision>
  				<origin xyz="0.0 0.0 0.0" rpy="0 0 0"/>
  				<geometry>
  					<box size="0.01 0.01 0.07"/>
  				</geometry>
  			</collision>
  		</link>	
  	</xacro:macro>
  
  	<mrobot_standoff_2in parent="base_link" number="1" x_loc="-${standoff_x/2 + 0.03}" y_loc="-${standoff_y - 0.03}" z_loc="${plate_height/2}" />
  	<mrobot_standoff_2in parent="base_link" number="2" x_loc="-${standoff_x/2 + 0.03}" y_loc="${standoff_y - 0.03}" z_loc="${plate_height/2}"/>
  	<mrobot_standoff_2in parent="base_link" number="3" x_loc="${standoff_x/2}" y_loc="-${standoff_y}" z_loc="${plate_height/2}"/>
  	<mrobot_standoff_2in parent="base_link" number="4" x_loc="${standoff_x/2}" y_loc="${standoff_y}" z_loc="${plate_height/2}"/>
  	
      <mrobot_standoff_2in parent="standoff_2in_1_link" number="5" x_loc="0" y_loc="0" z_loc="${plate_height}"/>
      <mrobot_standoff_2in parent="standoff_2in_2_link" number="6" x_loc="0" y_loc="0" z_loc="${plate_height}"/>
      <mrobot_standoff_2in parent="standoff_2in_3_link" number="7" x_loc="0" y_loc="0" z_loc="${plate_height}"/>
      <mrobot_standoff_2in parent="standoff_2in_4_link" number="8" x_loc="0" y_loc="0" z_loc="${plate_height}"/>
  	
  	
  	<xacro:macro name="mrobot_body">
  		<material name="Green">
  			<color rgba="0.0 0.8 0.0 1.0"/>
  		</material>
  		<material name="yellow">
  			<color rgba="1 0.4 0 1"/>
  		</material>
  		<material name="black">
  			<color rgba="0 0 0 0.95"/>
  		</material>
  		<material name="gray">
  			<color rgba="0.75 0.75 0.75 1"/>
  		</material>
  		
  		<link name="base_footprint">
  			<visual>
  				<origin xyz="0 0 0" rpy="0 0 0"/>
  				<geometry>
  					<box size="0.001 0.001 0.001"/>
  				</geometry>
  			</visual>
  		</link>
  		
  		<link name="base_link">
  			<inertial>
  				<mass value="2"/>
  				<origin xyz="0 0 0.0"/>
  				<inertia ixx="0.01" ixy="0.0" ixz="0.0"
  						 iyy="0.01" iyz="0.0" izz="0.5"/>
  			</inertial>
  			<visual>
  				<origin xyz="0 0 0" rpy="0 0 0"/>
  				<geometry>
  					<cylinder length="${base_link_length}" radius="${base_link_radius}"/>
  				</geometry>
  				<material name="yellow"/>
  			</visual>
  			<collision>
  				<origin xyz="0 0 0" rpy="0 0 0"/>
  				<geometry>
  					<cylinder length="${base_link_length}" radius="${base_link_radius}"/>
  				</geometry>
  			</collision>
  		</link>
  		
  		<joint name="base_footprint_joint" type="fixed">
  			<origin xyz="0 0 ${wheel_radius}" rpy="0 0 0"/>
  			<parent link="base_footprint"/>
  			<child link="base_link"/>
  		</joint>
  		
  		<link name="left_motor">
  			<inertial>
  				<origin xyz="0.0 0 0"/>
  				<mass value="0.1"/>
  				<inertia ixx="0.001" ixy="0.0" ixz="0.0"
  						 iyy="0.001" iyz="0.0" izz="0.001"/>
  			</inertial>
  			
  			<visual>
  				<origin xyz="0 0 0" rpy="${M_PI/2} 0 0"/>
  				<geometry>
  					<cylinder radius="${motor_radius}" length="${motor_length}"/>
  				</geometry>
  				<material name="gray"/>
  			</visual>
  			
  			<collision>
  				<origin xyz="0 0 0" rpy="${M_PI/2} 0 0"/>
  				<geometry>
  					<cylinder radius="${motor_radius}" length="${motor_length}"/>
  				</geometry>
  			</collision>	
  		</link>
  		
  		<joint name="base_left_motor_joint" type="fixed">
  			<origin xyz="${motor_x} ${motor_y} 0" rpy="0 0 0"/>
  			<parent link="base_link"/>
  			<child link="left_motor"/>
  		</joint>
  		
  		<link name="left_wheel_link">
  			<inertial>
  				<origin xyz="0 0 0"/>
  				<mass value="0.01"/>
  				<inertia ixx="0.001" ixy="0.0" ixz="0.0"
  						  iyy="0.001" iyz="0.0" izz="0.001"/>
  			</inertial>
  			
  			<visual>
  				<origin xyz="0 0 0" rpy="${M_PI/2} 0 0"/>
  				<geometry>
  					<cylinder radius="${wheel_radius}" length="${wheel_length}"/>
  				</geometry>
  				<material name="white">
  					<color rgba="1 1 1 0.9"/>
  				</material>
  			</visual>
  			
  				<collision>
  					<origin xyz="0 0 0" rpy="${M_PI/2} 0 0"/>
  					<geometry>
  						<cylinder radius="${wheel_radius}" length="${wheel_length}"/>
  					</geometry>
  				</collision>	
  		</link>
  		
  		<joint name="left_wheel_joint" type="continuous">
  			<origin xyz="0 ${(motor_length+wheel_length)/2} 0" rpy="0 0 0"/>
  			<parent link="left_motor"/>
  			<child link="left_wheel_link"/>
  			<axis xyz="0 1 0"/>
  		</joint>
  		
  		<link name="right_motor">
  			<inertial>
  				<origin xyz="0.0 0 0"/>
  				<mass value="0.1"/>
  				<inertia ixx="0.001" ixy="0.0" ixz="0.0"
  						 iyy="0.001" iyz="0.0" izz="0.001"/>
  			</inertial>
  			
  			<visual>
  				<origin xyz="0 0 0" rpy="${M_PI/2} 0 0"/>
  				<geometry>
  					<cylinder radius="${motor_radius}" length="${motor_length}"/>
  				</geometry>
  				<material name="gray"/>
  			</visual>
  			
  			<collision>
  				<origin xyz="0 0 0" rpy="${M_PI/2} 0 0"/>
  				<geometry>
  					<cylinder radius="${motor_radius}" length="${motor_length}"/>
  				</geometry>
  			</collision>			
  		</link>
  		
  		<joint name="base_right_motor_joint" type="fixed">
  			<origin xyz="${motor_x} -${motor_y} 0" rpy="0 0 0"/>
  			<parent link="base_link"/>
  			<child link="right_motor"/>
  		</joint>
  		
  		<link name="right_wheel_link">
  			<inertial>
  				<origin xyz="0 0 0"/>
  				<mass value="0.01"/>
  				<inertia ixx="0.001" ixy="0.0" ixz="0.0"
  						 iyy="0.001" iyz="0.0" izz="0.001"/>
  			</inertial>
  			
  			<visual>
  				<origin xyz="0 0 0" rpy="${M_PI/2} 0 0"/>
  				<geometry>
  					<cylinder radius="${wheel_radius}" length="${wheel_length}"/>
  				</geometry>
  				<material name="white">
  					<color rgba="1 1 1 0.9"/>
  				</material>
  			</visual>
  			
  			<collision>
  				<origin xyz="0 0 0" rpy="${M_PI/2} 0 0"/>
  				<geometry>
  					<cylinder radius="${wheel_radius}" length="${wheel_length}"/>
  				</geometry>
  			</collision>	
  		</link>
  		
  		<joint name="right_wheel_joint" type="continuous">
  			<origin xyz="0 -${(motor_length+wheel_length)/2} 0" rpy="0 0 0"/>
  			<parent link="right_motor"/>
  			<child link="right_wheel_link"/>
  			<axis xyz="0 1 0"/>
  		</joint>
  		
  		<link name="front_caster_link">
  			<inertial>
  				<origin xyz="0 0 0"/>
  				<mass value="0.001"/>
  				<inertia ixx="0.0001" ixy="0.0" ixz="0.0"
  						 iyy="0.0001" iyz="0.0" izz="0.0001"/>
  			</inertial>
  			
  			<visual>
  				<origin xyz="0 0 0" rpy="${M_PI/2} 0 0"/>
  				<geometry>
  					<sphere radius="${wheel_radius/2}"/>
  				</geometry>
  				<material name="black"/>
  			</visual>
  			
  			<collision>
  				<origin xyz="0 0 0.01" rpy="${M_PI/2} 0 0"/>
  				<geometry>
  					<sphere radius="${wheel_radius/2}"/>
  				</geometry>
  			</collision>		
  		</link>
  		
  		<joint name="front_caster_joint" type="fixed">
  			<origin xyz="${base_link_radius-wheel_radius/2} 0 -${wheel_radius/2}" rpy="0 0 0"/>
  			<parent link="base_link"/>
  			<child link="front_caster_link"/>
  		</joint>
  		
  		
  		<joint name="plate_1_joint" type="fixed">
  			<origin xyz="0 0 ${plate_height}" rpy="0 0 0"/>
  			<parent link="base_link"/>
  			<child link="plate_1_link"/>
  		</joint>
  		
  		<link name="plate_1_link">
  			<inertial>
  				<mass value="0.1"/>
  				<origin xyz="0 0 0"/>
                  <inertia ixx="0.01" ixy="0.0" ixz="0.0"
                           iyy="0.01" iyz="0.0" izz="0.01" />
  
  			</inertial>
  			
  			<visual>
  				<origin xyz="0 0 0" rpy="0 0 0"/>
  				<geometry>
  					<cylinder length="${base_link_length}" radius="${base_link_radius}"/>
  				</geometry>
  				<material name="yellow"/>
  			</visual>
  			
  			<collision>
  				<origin xyz="0.0 0.0 0.0" rpy="0 0 0"/>
  				<geometry>
  					<cylinder length="${base_link_length}" radius="${base_link_radius}"/>
  				</geometry>
  			</collision>			
  		</link>
  		
  		<joint name="plate_2_joint" type="fixed">
  			<origin xyz="0 0 ${plate_height}" rpy="0 0 0"/>
  			<parent link="plate_1_link"/>
  			<child link="plate_2_link"/>
  		</joint>
  		
  		<link name="plate_2_link">
  			<inertial>
  				<mass value="0.01"/>
  				<origin xyz="0 0 0"/>
  				<inertia ixx="0.001" ixy="0.0" ixz="0.0"
  						 iyy="0.001" iyz="0.0" izz="0.001"/>
  			</inertial>
  			
  			<visual>
  				<origin xyz="0 0 0" rpy="0 0 0"/>
  				<geometry>
  					<cylinder length="${base_link_length}" radius="${base_link_radius}"/>
  				</geometry>
  				<material name="yellow"/>
  			</visual>
  			
  			<collision>
  				<origin xyz="0.0 0.0 0.0" rpy="0 0 0"/>
  				<geometry>
  					<cylinder length="${base_link_length}" radius="${base_link_radius}"/>
  				</geometry>
  			</collision>
  		</link>
  		
  		
  	</xacro:macro>
  
  </robot>
  
  
  ```

  `display_mrobot.launch`文件：

  ```xml
  <launch>
  	<arg name="model" default="$(find xacro)/xacro --inorder '$(find mrobot_description)/urdf/mrobot.urdf.xacro'" />
  	<arg name="gui" default="true"/>
  	
  	<param name="robot_description" command="$(arg model)"/>
  	
  	<!-- 设置GUI参数，显示关节控制插件 -->
  	<param name="use_gui" value="$(arg gui)"/>
  
  	<!-- 运行joint_state_publisher_gui节点，发布机器人的关节状态 -->
  	<node name="joint_state_publisher_gui" pkg="joint_state_publisher_gui" type="joint_state_publisher_gui"/>
  	
  	<!-- 运行robot_state_publisher节点，发布tf -->
  	<node name="robot_state_publisher" pkg="robot_state_publisher" type="robot_state_publisher"/>
  	
  	<!-- 运行rviz可视化界面 -->
  	<node name="rviz" pkg="rviz" type="rviz" args="-d $(find mrobot_description)/config/mrobot.rviz" required="true"/>
  	
  </launch>
  
  ```

  运行launch文件可以看到优化后的模型：

  ```C++
  $roslaunch mrobot_description display_mrobot.launch
  ```

  ![](image/rviz_module2.png "小车模型")  

  

  ## 6.4 添加传感器模型 

  ### 6.4.1 添加摄像头

  

  

  

  ## 安装map_server、gmapping等功能包

  在ROS melodic中，很多功能包没有提供`sudo apt-get install`的安装方式，这是就需要源码安装。
  
  ### 下载源码
  
  进入工作空间：
  
  `$cd ~/catkin_ws/src/`
  
  下载源代码：
  
  ```C++
  $ git clone https://github.com/ros/geometry2.git
  $ git clone https://github.com/ros-planning/navigation.git
  $ git clone https://github.com/ros-planning/navigation_msgs.git
  $ git clone https://github.com/ros-perception/slam_gmapping.git
  $ git clone https://github.com/ros-perception/openslam_gmapping.git
  
  ```
  
  ### 编译源代码
  
  ```C++
  ~/catkin_ws$catkin_make
  ```
  
  等待编译完成，OK！
  
  

### 9.5.1 cartographer功能包 

- 1.安装工具

  使用如下命令安装工具：

  ```C++
  $sudo apt-get update	
  $sudo apt-get install -y python-wstool python-rosdep ninja-build
  ```

- 2.初始化工作空间

  ```C++
  $cd catkin_google_ws
  $wstool init src
  ```

- 3.加入cartographer_ros.rosinstall并更新依赖

  命令如下：

  ```C++
  $wstool merge -t src https://raw.githubusercontent.com/googlecartographer/cartographer_ros/master/cartographer_ros.rosinstall
  $wstool update -t src
  ```

  注意：如果下载服务器无法连接，使用下面命令修改`ceres-solver`源码的下载地址为：

  `https://github.com/ceres-solver/ceres-solver.git` 如下代码所示：

  ```
  # THIS IS AN AUTOGENERATED FILE, LAST GENERATED USING wstool ON 2020-03-11
  - git:
      local-name: cartographer
      uri: https://github.com/googlecartographer/cartographer.git
      version: 1.0.0
  - git:
      local-name: cartographer_ros
      uri: https://github.com/googlecartographer/cartographer_ros.git
      version: 1.0.0
  - git:
      local-name: ceres-solver
  #    uri: https://ceres-solver.googlesource.com/ceres-solver.git
      uri: https://github.com/ceres-solver/ceres-solver.git
      version: 1.13.0
  ```

- 4.安装依赖并下载`cartographer`相关功能包

  命令如下：

  ```C++
  $rosdep update
  $rosdep install --from-paths src --ignore-src --rosdistro=${ROS_DISTRO} -y
  ```

- 5.编译并安装

  命令如下：

  ```C++
  $catkin_make_isolated --install --use-ninja
  $source install_isolated/setup.bash
  ```

### 9.5.2 官方Demo测试

谷歌为cartographer提供了多种官方demo，可以直接下载官方录制好的数据包进行测试。

- 1. 2D slam demo

  使用下面命令下载并运行demo:

  ```C++
  $wget -P ~/Downloads https://storage.googleapis.com/cartographer-public-data/bags/backpack_2d/cartographer_paper_deutsches_museum.bag
  $roslaunch cartographer_ros demo_backpack_2d.launch bag_filename:=${HOME}/Downloads/cartographer_paper_deutsches_museum.bag
  ```

- 2. 3D slam demo

     使用下面命令下载并运行demo：

     ```C++
     $wget -P ~/Downloads https://storage.googleapis.com/cartographer-public-data/bags/backpack_3d/with_intensities/b3-2016-04-05-14-14-00.bag
     $roslaunch cartographer_ros demo_backpack_3d.launch bag_filename:=${HOME}/Downloads/b3-2016-04-05-14-14-00.bag
     ```

     ![](image/3D_slam_demo.png "3D slam demo") 

- 3. Revo LDS demo

     使用下面命令下载并运行demo：

     ```C++
     $wget -P ~/Downloads https://storage.googleapis.com/cartographer-public-data/bags/revo_lds/cartographer_paper_revo_lds.bag
     $roslaunch cartographer_ros demo_revo_lds.launch bag_filename:=${HOME}/Downloads/cartographer_paper_revo_lds.bag
     ```

     ![](image/Revo_LDS_Demo1.png "Revo LDS demo运行结果") 

- 4. PR2 demo

     使用如下命令下载并运行demo:

     ```C++
     $wget -P ~/Downloads https://storage.googleapis.com/cartographer-public-data/bags/pr2/2011-09-15-08-32-46.bag
     $roslaunch cartographer_ros demo_pr2.launch bag_filename:=${HOME}/Downloads/2011-09-15-08-32-46.bag
     ```

     ![](image/RP2_slam_dema.png "PR2 slam demo") 



### 9.8.1 导航框架

导航的关键是机器人的定位和路径规划两大部分。针对这两个核心，ROS提供了一下两个功能包。

- 1）move_base:实现机器人导航中的最优路径规划。
- 2）amcl:实现二维地图中的机器人定位。

在上述两个





## 插曲

### Rebuilding a single catkin package

```c++
$cd ~/catkin_ws
$catkin_make --pkg package_name
```

这样可以单独编译一个功能包。



### Eclipse下环境搭建

```C++
$catkin_make --force-cmake -G"Eclipse CDT4 - Unix Makefiles"
```

上述命令会产生一个`.project`文件，然后接着运行：

```C++
$awk -f $(rospack find mk)/eclipse.awk build/.project > build/.project_with_env && mv build/.project_with_env build/.project
```

为了能够调试代码，接着运行下面命令：

```C++
$cmake ../src -DCMAKE_BUILD_TYPE=Debug
```



### 安装jdk环境

```C++

export JAVA_HOME=/usr/local/jdk1.8.0_241
export JRE_HOME=${JAVA_HOME}/jre
export CLASSPATH=.:${JAVA_HOME}/lib:${JRE_HOME}/lib
export PATH=.:${JAVA_HOME}/bin:$PATH
```

缺少库文件：

```C++
查找libjli.so文件 

 mv /usr/local/jdk1.6.0_13/jre/lib/i386/jli/libjli.so /lib
```

### 解决Debug运行报错

![](image/eclipse_debug1.png) 

参考链接：https://www.cnblogs.com/smartvessel/archive/2011/01/21/1940868.html

总结下来主要有三种办法：

首先在Linux下搜索缺少的库文件

`$grep "libcpp_common.so" * -nR` 

![](image/eclipse_debug2.png) 

第一：用`ln`将需要的`so`问价链接到`/usr/lib`或者`/lib`这两个默认的目录下边

```C++
$ln -s /opt/ros/melodic/lib/libcpp_common.so /usr/lib

$sudo ldconfig
```

第二：修改`LD_LIBRARY_PATH`

```C++
$export LD_LIBRARY_PATH=/opt/ros/melodic/lib:$LD_LIBRARY_PATH

$sudo ldconfig
```

第三：修改`/etc/ld.so.conf`,然后刷新

`$vim /etc/ld.so.conf`

增加： `/opt/ros/melodic/lib`

`$sudo ldconfig`

接着运行debug，依然报错：

![](image/eclipse_debug3.png) 

需要添加环境变量，先查看内容：

```C++
$echo ROS_ROOT
$echo ROS_MASTER_URI
```

![](image/eclipse1.png) 

然 后在eclipse菜单栏`run` -> `run configurations`页面设置如下：

![](image/eclipse2.png) 

要启动调试，首先需要启动`roscore`,然后在选择需要调试的应用

![](image/eclipse3.png) 

然后在运行，发现调试窗口会出现乱码，需要安装ANSI escape sequences插件解决





### 主从网络通信

参考链接：https://blog.csdn.net/renyuanxingxing/article/details/90349575

使用ip地址代替计算机名字





## 串口通信 

官方文档：http://wiki.ros.org/serial

```C++
/*
 * file name:serial_port.cpp
 * */

#include "serial_port/serial_port.h"

namespace agvrobot
{

const unsigned char header[2] = {0x55,0xaa};
const unsigned char ender[2] = {0x0d,0x0a};
const int SPEED_INFO = 0xa55a;
const int GET_SPEED = 0xaaaa;
const double ROBOT_RADIUS = 105.00;
const double ROBOT_LENGTH = 210.50;

AgvSerial::AgvSerial()
{

}

AgvSerial::~AgvSerial()
{

}

bool AgvSerial::init()
{
	//创建一个serial类
	serial::Timeout to = serial::Timeout::simpleTimeout(100);
	sp.setPort("/dev/ttyUSB0");
	sp.setBaudrate(115200);
	sp.setTimeout(to);
	try{
		sp.open();
	} catch(serial::IOException& e)
	{
		ROS_ERROR_STREAM("Unable to open port");
		return 1;
	}

	//判断串口是否打开
	if ( sp.isOpen() )
	{
		ROS_INFO_STREAM("/dev/ttyUSB0 is opened");
	}
	else
	{
		return 1;
	}
	return 0;
}

bool AgvSerial::readDate()
{
#if 0
	uint8_t rx_buf[64];
	//获取缓冲区的字节
	size_t n = sp.available();
	sp.read(rx_buf,n);
#endif

	int i,length = 0;
	uint8_t checkSum;
	uint8_t buf[64];

	//读取串口数据
	size_t n = sp.available();
	sp.read(buf,n);

	//接收头部信息
	for ( i=0; i<2; i++ )
		receive_header.data[i] = buf[i];

	//检查信息头
	if ( receive_header.data[0] != header[0] || receive_header.data[1] != header[1] )
	{
		ROS_ERROR("Received message header error!");
		return false;
	}

	//接收命令字节
	for ( i=0; i<2; i++ )
		receive_command.data[i] = buf[i+2];

	//检查命令字节
	if ( receive_command.d != SPEED_INFO )
	{
		ROS_ERROR("Received command error");
		return false;
	}

	//检查信息尾
	if ( buf[6+length] != ender[0] || buf[7+length] != ender[1] )
	{
		ROS_ERROR("Received message header error");
		return false;
	}

	//接收校验值
	length = buf[4];
	checkSum = getCrc8(buf, 5+length);
	ReceiveCheckSum.data[0] = buf[5+length];
	if ( checkSum != ReceiveCheckSum.d )
	{
		ROS_ERROR("Received data check sum error");
		return false;
	}

	//读取速度
	for(i=0; i<4; i++)
	{
		vel_left.odometry_char[i] = buf[i+5];
		vel_right.odometry_char[i] = buf[i+9];
	}

	return true;
}

void AgvSerial::writeDate(double RobotV, double YawRate)
{
	unsigned char buf[16] = {0};
	int i=0,length = 0;
	double r = RobotV / YawRate ;

//	uint8_t tx_buf[6]="Hello";
//	sp.write(tx_buf,6);


	//设置消息头
	for(i = 0; i<2; i++)
		buf[i] = header[i];

	//设置消息类型
	send_command.d = GET_SPEED;
	for ( i=0; i<2; i++ )
		buf[i+2] = send_command.data[i];

	//设置左右轮速度
	length = 8;
	buf[4] = length;
	for(i=0; i<4; i++)
	{
		buf[i+5] = rightdata.data[i];
		buf[i+9] = leftdata.data[i];
	}

	//设置校验值、消息尾
	buf[5 + length] = getCrc8(buf, 5+length);
	buf[6 + length] = ender[0];
	buf[7 + length] = ender[1];

	sp.write(buf,16);

}

bool AgvSerial::spinOnce(double RobotV, double YawRate)
{
	writeDate(RobotV, YawRate);
	readDate();
	return true;
}

uint8_t AgvSerial::getCrc8(unsigned char *ptr, unsigned short len)
{
	unsigned char crc;
	unsigned char i;
	crc = 0;
	while(len--)
	{
		crc ^= *ptr++;
		for(i = 0; i < 8; i++)
		{
			if(crc&0x01)
                crc=(crc>>1)^0x8C;
			else
                crc >>= 1;
		}
	}
	return crc;
}
}  /* namespace agvrobot */


```

```C++
/*
 * file name:agv_main.cpp
 *
 * */

#include "serial_port/serial_port.h"


double RobotV_ = 1.0;
double YawRate_ = 1.0;

int main(int argc, char **argv)
{
	ros::init(argc, argv, "agv_robot");
	ros::NodeHandle n;

	//初始化串口
	agvrobot::AgvSerial uart;
	if ( uart.init() )
		ROS_ERROR("Serial init failed!");
	else ROS_INFO("Serial init successful!");

	ros::Rate loop_rate(50);

	while(ros::ok())
	{
		ros::spinOnce();

		//调用串口控制
		uart.spinOnce(RobotV_,YawRate_);

		loop_rate.sleep();
	}

}


```

```C++
/*
 * file name : serial_port.h
 * */

#ifndef SERIAL_PORT_H
#define SERIAL_PORT_H

#include <ros/ros.h>
#include <serial/serial.h>
#include <ros/time.h>


namespace agvrobot
{
class AgvSerial
{
public:
	AgvSerial();
	~AgvSerial();
	bool init();
	bool spinOnce(double RobotV, double YawRate);
	uint8_t getCrc8(unsigned char *ptr, unsigned short len);

	serial::Serial sp;

	union sendData
	{
		int d;
		unsigned char data[4];
	}leftdata, rightdata;

	union checkSum
	{
		short d;
		unsigned char data[1];
	}SendCheckSum, ReceiveCheckSum;

	union receiveHeader
	{
		int d;
		unsigned char data[2];
	}receive_command, receive_header;

	union sendCommand
	{
		int d;
		unsigned char data[2];
	}send_command;

	union odometry
	{
		float odoemtry_float;
		unsigned char odometry_char[4];
	}vel_left, vel_right;


private:
	bool readDate();
	void writeDate(double RobotV, double YawRate);



};  /* class AgvSerial */




}  /* namespace agvrobot */





#endif  /* SERIAL_PORT_H */

```

需要在`CMakeLists.txt`修改的内容：

```C++
## Compile as C++11, supported in ROS Kinetic and newer
  add_compile_options(-std=c++11)

###########
## Build ##
###########

## Specify additional locations of header files
## Your package locations should be listed before other locations
include_directories(
 include
  ${catkin_INCLUDE_DIRS}
)
      
      
add_executable(serial_port src/agv_main.cpp src/serial_port.cpp)
target_link_libraries(serial_port ${catkin_LIBRARIES})

      
```

